# kafka-avro
Examples of working with Avro (de)serialization

Check the full blog post at coding harbour: [Guide to apache Avro and Kafka](https://codingharbour.com/apache-kafka/guide-to-apache-avro-and-kafka/)
